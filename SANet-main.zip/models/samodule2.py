import torch
import torch.nn as nn
import torch.nn.functional as F
from models.SAM.batchnorm import SynchronizedBatchNorm2d
from models.SAM.aspp_module import A_spp
from models.SAM.decoder import Decoder_f
from models.SAM.backbone import Backbone 

class SAModule(nn.Module):
    def __init__(self, num_classes=19, backbone='resnet', output_stride=16, num_channels=21,
                 sync_bn=True, freeze_bn=False):
        super(SAModule, self).__init__()
        if backbone == 'drn':
            output_stride = 8

        if sync_bn == True:
            BatchNorm = SynchronizedBatchNorm2d
        else:
            BatchNorm = nn.BatchNorm2d

        self.backbone = Backbone(backbone, output_stride, BatchNorm)
        self.aspp = A_spp(backbone, output_stride, BatchNorm)
        self.decoder = Decoder_f(num_classes, backbone, BatchNorm)

        self.freeze_bn = freeze_bn

    def forward(self, input, fea, fea_l):
        if fea==None:
            x, low_level_feat = self.backbone(input)
        else: 
            
              x=fea, low_level_feat=fea_l
        print(x.size())
        print(low_level_feat.size())
        s_f = self.aspp(x)
        seg_map = self.decoder(s_f, low_level_feat)
        
        s_f_up = F.interpolate(s_f, size=low_level_feat.size()[2:], mode='bilinear', align_corners=True)
        
        return seg_map, s_f_up
            
            

        

    def freeze_bn(self):
        for m in self.modules():
            if isinstance(m, SynchronizedBatchNorm2d):
                m.eval()
            elif isinstance(m, nn.BatchNorm2d):
                m.eval()

    def get_1x_lr_params(self):
        modules = [self.backbone]
        for i in range(len(modules)):
            for m in modules[i].named_modules():
                if self.freeze_bn:
                    if isinstance(m[1], nn.Conv2d):
                        for p in m[1].parameters():
                            if p.requires_grad:
                                yield p
                else:
                    if isinstance(m[1], nn.Conv2d) or isinstance(m[1], SynchronizedBatchNorm2d) \
                            or isinstance(m[1], nn.BatchNorm2d):
                        for p in m[1].parameters():
                            if p.requires_grad:
                                yield p

    def get_10x_lr_params(self):
        modules = [self.aspp, self.decoder]
        for i in range(len(modules)):
            for m in modules[i].named_modules():
                if self.freeze_bn:
                    if isinstance(m[1], nn.Conv2d):
                        for p in m[1].parameters():
                            if p.requires_grad:
                                yield p
                else:
                    if isinstance(m[1], nn.Conv2d) or isinstance(m[1], SynchronizedBatchNorm2d) \
                            or isinstance(m[1], nn.BatchNorm2d):
                        for p in m[1].parameters():
                            if p.requires_grad:
                                yield p

if __name__ == "__main__":
    model = SAModule(backbone='mobilenet', output_stride=16)
    model.eval()
    input = torch.rand(1, 3, 256, 512)
    output, _ = model(input)
    


