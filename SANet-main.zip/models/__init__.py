# -*- coding: utf-8 -*-
from .basic import PSMNet as basic
from .stackhourglass import PSMNet as stackhourglass
from .stackhourglass_stack_add1 import Hg_cor
from .SANet import SANet 
from .SANet_2 import SANet as SANet2
from .SANet_3 import SANet as SANet3
from .SANet_4 import SANet as SANet4
from .SANet_5 import SANet as SANet5
from .SANet_6 import SANet as SANet6


__models__ = {
    "base" : basic,
    "hourglass": stackhourglass,
    "hg_cor" : Hg_cor,
    "sanet" : SANet,
    "sanet_2": SANet2,
    "sanet_3": SANet3,
    "sanet_4": SANet4,
    "sanet_5": SANet5,
    "sanet_6": SANet6,

}

