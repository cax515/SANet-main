# -*- coding: utf-8 -*-
#need to change models.init
from __future__ import print_function
import argparse
import os
import random
import torch
import torch.nn as nn
import torch.nn.parallel
import torch.backends.cudnn as cudnn
import torch.optim as optim
import torch.utils.data
from torch.autograd import Variable
import torch.nn.functional as F
import numpy as np
import time
import math
from dataloader import KITTILoader2012 as ls
from dataloader import KITTILoader as DA
from models import * 
from tensorboardX import SummaryWriter
from utils import *
parser = argparse.ArgumentParser(description='SANet_forkitti2012')
parser.add_argument('--maxdisp', type=int, default=192, help='maxium disparity')  
parser.add_argument('--model', default='SANet_6', help='select model')  
parser.add_argument('--datapath', default='/data/wlxu/DataSet/KITTI2012/', help='datapath')
parser.add_argument('--pre_train', default='Seg_checkpoint/model_best.pth.tar', help='datapath') 
parser.add_argument('--epochs', type=int, default=300, help='number of epochs to train')
parser.add_argument('--l_dw', type=int, default=1, help='weight of loss_disp to train')
parser.add_argument('--loadmodel', default=None, help='load model')
parser.add_argument('--savemodel', default='./checkpoint/', help='save model')
parser.add_argument('--no-cuda', action='store_true', default=False, help='enables CUDA training')
parser.add_argument('--seed', type=int, default=1, metavar='S', help='random seed (default: 1)')
parser.add_argument('--lr', type=float, default=0.001, metavar='S', help='random lr (default: 1)')
args = parser.parse_args()
#args.cuda = not args.no_cuda and torch.cuda.is_available()

print(args)
writer = SummaryWriter('./runs/exp1')
if not os.path.exists(args.savemodel):
   os.makedirs(args.savemodel)

l_dw = args.l_dw

# set gpu id used
os.environ["CUDA_VISIBLE_DEVICES"] = "4,5"


torch.cuda.manual_seed(1)

all_left_img, all_right_img, all_left_disp, test_left_img, test_right_img, test_left_disp = ls.dataloader(args.datapath)  # 返回路径

TrainImgLoader = torch.utils.data.DataLoader(
                DA.myImageFloder(all_left_img, all_right_img, all_left_disp, True),
                  batch_size=4, shuffle=True, num_workers=2, drop_last=True)


TestImgLoader = torch.utils.data.DataLoader(
              DA.myImageFloder(test_left_img, test_right_img, test_left_disp, False),
                  batch_size=4, shuffle=False, num_workers=2, drop_last=True)

print("traindata.size()", len(TrainImgLoader))




if args.model == 'stackhourglass':
    model = stackhourglass(args.maxdisp)
elif args.model == 'basic':
    model = basic(args.maxdisp)
elif args.model =='Hg_cor':
    model = HG_cor(args.maxdisp)
elif args.model =='SANet':
    model = SANet(args.maxdisp, args.pre_train)
elif args.model =='SANet_2':
    model = SANet2(args.maxdisp, args.pre_train)
elif args.model =='SANet_3':
    model = SANet3(args.maxdisp, args.pre_train)
elif args.model =='SANet_4':
    model = SANet4(args.maxdisp, args.pre_train)
elif args.model =='SANet_5':
    model = SANet5(args.maxdisp, args.pre_train)
elif args.model =='SANet_6':
    model = SANet6(args.maxdisp, args.pre_train)
else:
    print('no model')

hourglassnet = ["SANet", "SANet_2", "SANet_3", "SANet_4", "SANet_5", "SANet_6"]

if True:
    model = nn.DataParallel(model)
    model.cuda()
    

if args.loadmodel!= None :  
    loadmodel = args.loadmodel
    state_dict = torch.load(loadmodel)
    model.load_state_dict(state_dict['state_dict'])


    

print('Number of model parameters: {}'.format(sum([p.data.nelement() for p in model.parameters()])))

optimizer = optim.Adam(model.parameters(), lr=0.001, betas=(0.9, 0.999))

def train(imgL, imgR, disp_L):
    model.train()
    imgL = Variable(torch.FloatTensor(imgL))
    imgR = Variable(torch.FloatTensor(imgR))
    disp_L = Variable(torch.FloatTensor(disp_L))

    if True:
        imgL, imgR, disp_true = imgL.cuda(), imgR.cuda(), disp_L.cuda()

    mask = (disp_true < args.maxdisp) & (disp_true > 0)
    mask.detach_()
    #print("this is img_size:", imgL.size())

    optimizer.zero_grad()
    
    if args.model == 'Hg_cor' or args.model in hourglassnet:
       
        seg_l, output0, output1, output2 = model(imgL, imgR)
        
        output0 = torch.squeeze(output0,1)
        output1 = torch.squeeze(output1,1)
        output2 = torch.squeeze(output2,1)
        
        loss_disp = 0.5*F.smooth_l1_loss(output0[mask],disp_true[mask], size_average=True)+0.7 * F.smooth_l1_loss(output1[mask], disp_true[mask], size_average=True) + 1.0 *F.smooth_l1_loss(output2[mask], disp_true[mask], size_average=True) 
        loss_bod = get_disparity_smoothness_loss(output2, seg_l)
        loss = l_dw*loss_disp + (1-l_dw)*loss_bod
        
        loss.backward()
        optimizer.step()
        return loss.data
        
    elif args.model == 'basic':
        output = model(imgL, imgR)
        output = torch.squeeze(output, 1)
        loss = F.smooth_l1_loss(output[mask], disp_true[mask], size_average=True)
        
        loss.backward()
        optimizer.step()
        return loss.data
    


def adjust_learning_rate(optimizer, epoch):
    lr = args.lr
    if epoch <= 200:
        lr = args.lr
    else:
        lr = args.lr / 10.
    print(lr)
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr




def main():
    start_full_time = time.time()
    Min_loss = 200
    Min_Epoch = 0
    for epoch in range(1, args.epochs + 1):
        print('This is %d-th epoch' % (epoch))
        total_train_loss = 0
        adjust_learning_rate(optimizer, epoch)

        ## training ##
        for batch_idx, (imgL_crop, imgR_crop, disp_crop_L) in enumerate(TrainImgLoader):
            start_time = time.time()
            try:
                loss_z = train(imgL_crop, imgR_crop, disp_crop_L)
            except RuntimeError as exception:
              if "out of memory" in str(exception):
                  print("WARNING: out of memory")
                  if hasattr(torch.cuda, 'empty_cache'):
                      torch.cuda.empty_cache()
              else:
                  raise exception
            #print(loss_z)
            print('this is %d epoch Iter %d training loss = %.3f , time = %.2f' % (epoch, batch_idx, loss_z, time.time() - start_time))
            total_train_loss += loss_z
            writer.add_scalar('loss', loss_z, (epoch-1)*(len(TrainImgLoader)/4)+batch_idx, time.time() )
        print('epoch %d total training loss = %.3f' % (epoch, total_train_loss / len(TrainImgLoader)))
        if Min_loss > total_train_loss / len(TrainImgLoader):
          Min_loss = total_train_loss / len(TrainImgLoader)
          Min_Epoch = epoch
        print('min_loss: %d ,min_epoch: %d' % (Min_loss, Min_Epoch))
        writer.add_scalar('total_loss', total_train_loss / len(TrainImgLoader), epoch, time.time() )
        # SAVE
        if epoch > 250 :
            savefilename = args.savemodel + '/checkpoint_' + str(epoch) + '.tar'
            torch.save({
              'epoch': epoch,
              'state_dict': model.state_dict(),
              'train_loss': total_train_loss / len(TrainImgLoader),
              }, savefilename)

    print('full training time = %.2f HR' % ((time.time() - start_full_time) / 3600))
    print("Min_loss:%.3f" % (Min_loss))
    print(Min_Epoch)
    writer.close()
   



if __name__ == '__main__':
    main()