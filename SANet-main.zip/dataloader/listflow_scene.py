import torch.utils.data as data

from PIL import Image
import os
import os.path

IMG_EXTENSIONS = [
    '.jpg', '.JPG', '.jpeg', '.JPEG',
    '.png', '.PNG', '.ppm', '.PPM', '.bmp', '.BMP',
]


def is_image_file(filename):
    return any(filename.endswith(extension) for extension in IMG_EXTENSIONS)


def dataloader(filepath):
    classes = [d for d in os.listdir(filepath) if os.path.isdir(os.path.join(filepath, d))]
    monkaa_d = [img for img in classes if img.find('monkaa') > -1]
    driving_d = [img for img in classes if img.find('driving') > -1]
    flything_d = [img for img in classes if img.find('flyingthings') > -1]

    driving_path = filepath + driving_d[0] + '/'
    print(flything_d)

    im_or_dp = [d for d in os.listdir(filepath+monkaa_d[0]) if os.path.isdir(os.path.join(filepath+monkaa_d[0], d))]
    #print(im_or_dp)
    image = [img for img in im_or_dp if img.find('frames_cleanpass') > -1]
    disp = [dsp for dsp in im_or_dp if dsp.find('disparity') > -1]
    #print(image)
    #print(disp)
    monkaa_path = filepath+monkaa_d[0] + '/' + image[0]
    monkaa_disp = filepath+monkaa_d[0] + '/' + disp[0]

    monkaa_dir = os.listdir(monkaa_path)

    all_left_img = []
    all_right_img = []
    all_left_disp = []
    test_left_img = []
    test_right_img = []
    test_left_disp = []






    # driving data
    driving_dir = driving_path + 'frames_cleanpass/'
    driving_disp = driving_path + 'disparity/'

    subdir1 = ['35mm_focallength', '15mm_focallength']
    subdir2 = ['scene_backwards', 'scene_forwards']
    subdir3 = ['fast', 'slow']

    for i in subdir1:
        for j in subdir2:
            for k in subdir3:
                imm_l = os.listdir(driving_dir + i + '/' + j + '/' + k + '/left/')
                for im in imm_l:
                    if is_image_file(driving_dir + i + '/' + j + '/' + k + '/left/' + im):
                        all_left_img.append(driving_dir + i + '/' + j + '/' + k + '/left/' + im)
                    all_left_disp.append(
                        driving_disp + '/' + i + '/' + j + '/' + k + '/left/' + im.split(".")[0] + '.pfm')

                    if is_image_file(driving_dir + i + '/' + j + '/' + k + '/right/' + im):
                        all_right_img.append(driving_dir + i + '/' + j + '/' + k + '/right/' + im)
    test_left_img = all_left_img[0:20]
    test_right_img = all_right_img[0:20]
    test_left_disp = all_left_disp[0:20]
    return all_left_img, all_right_img, all_left_disp, test_left_img, test_right_img, test_left_disp