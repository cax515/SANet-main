import torch.utils.data as data

from PIL import Image
import os
import os.path

IMG_EXTENSIONS = [
    '.jpg', '.JPG', '.jpeg', '.JPEG',
    '.png', '.PNG', '.ppm', '.PPM', '.bmp', '.BMP',
]


def is_image_file(filename):
    return any(filename.endswith(extension) for extension in IMG_EXTENSIONS)


def dataloader(filepath):
    classes = [d for d in os.listdir(filepath) if os.path.isdir(os.path.join(filepath, d))]
    monkaa_d = [img for img in classes if img.find('monkaa') > -1]
    driving_d = [img for img in classes if img.find('driving') > -1]
    flything_d = [img for img in classes if img.find('flyingthings') > -1]

    driving_path = filepath + driving_d[0] + '/'
    print(flything_d)

    im_or_dp = [d for d in os.listdir(filepath+monkaa_d[0]) if os.path.isdir(os.path.join(filepath+monkaa_d[0], d))]
    #print(im_or_dp)
    image = [img for img in im_or_dp if img.find('frames_cleanpass') > -1]
    disp = [dsp for dsp in im_or_dp if dsp.find('disparity') > -1]
    #print(image)
    #print(disp)
    monkaa_path = filepath+monkaa_d[0] + '/' + image[0]
    monkaa_disp = filepath+monkaa_d[0] + '/' + disp[0]

    monkaa_dir = os.listdir(monkaa_path)

    all_left_img = []
    all_right_img = []
    all_left_disp = []
    test_left_img = []
    test_right_img = []
    test_left_disp = []

    for dd in monkaa_dir:
        for im in os.listdir(monkaa_path + '/' + dd + '/left/'):
            if is_image_file(monkaa_path + '/' + dd + '/left/' + im):
                all_left_img.append(monkaa_path + '/' + dd + '/left/' + im)
                all_left_disp.append(monkaa_disp + '/' + dd + '/left/' + im.split(".")[0] + '.pfm')

        for im in os.listdir(monkaa_path + '/' + dd + '/right/'):
            if is_image_file(monkaa_path + '/' + dd + '/right/' + im):
                all_right_img.append(monkaa_path + '/' + dd + '/right/' + im)


    #flyingthing
    im_or_dp = [d for d in os.listdir(filepath + flything_d[0]) if os.path.isdir(os.path.join(filepath + flything_d[0], d))]
    print(im_or_dp)
    fly_image = [img for img in im_or_dp if img.find('flythings3D_image') > -1]
    fly_disp = [dsp for dsp in im_or_dp if dsp.find('disparity') > -1]
    fly_impath = filepath + flything_d[0] + '/' + fly_image[0] + '/FlyingThings3D_subset/train/image_clean'
    fly_dispath = filepath + flything_d[0] + '/' + fly_disp[0] + '/FlyingThings3D_subset/train/disparity'

    for im in os.listdir(fly_impath + '/' + '/left/'):
        if is_image_file(fly_impath + '/' + '/left/' + im):
            all_left_img.append(fly_impath + '/' + '/left/' + im)
            all_left_disp.append(fly_dispath + '/' + '/left/' + im.split(".")[0] + '.pfm')

    for im in os.listdir(fly_impath + '/' + '/right/'):
        if is_image_file(fly_impath + '/' + '/right/' + im):
            all_right_img.append(fly_impath + '/' + '/right/' + im)

    #flyingthings testdata
    fly_impath_val = filepath + flything_d[0] + '/' + fly_image[0] + '/FlyingThings3D_subset/val/image_clean'
    fly_dispath_val = filepath + flything_d[0] + '/' + fly_disp[0] + '/FlyingThings3D_subset/val/disparity'
    for im in os.listdir(fly_impath_val + '/' + '/left/'):
        if is_image_file(fly_impath_val + '/' + '/left/' + im):
            test_left_img.append(fly_impath_val + '/' + '/left/' + im)
            test_left_disp.append(fly_dispath_val + '/' + '/left/' + im.split(".")[0] + '.pfm')

    for im in os.listdir(fly_impath_val + '/' + '/right/'):
        if is_image_file(fly_impath_val + '/' + '/right/' + im):
            test_right_img.append(fly_impath_val + '/' + '/right/' + im)

    # driving data
    driving_dir = driving_path + 'frames_cleanpass/'
    driving_disp = driving_path + 'disparity/'

    subdir1 = ['35mm_focallength', '15mm_focallength']
    subdir2 = ['scene_backwards', 'scene_forwards']
    subdir3 = ['fast', 'slow']

    for i in subdir1:
        for j in subdir2:
            for k in subdir3:
                imm_l = os.listdir(driving_dir + i + '/' + j + '/' + k + '/left/')
                for im in imm_l:
                    if is_image_file(driving_dir + i + '/' + j + '/' + k + '/left/' + im):
                        all_left_img.append(driving_dir + i + '/' + j + '/' + k + '/left/' + im)
                    all_left_disp.append(
                        driving_disp + '/' + i + '/' + j + '/' + k + '/left/' + im.split(".")[0] + '.pfm')

                    if is_image_file(driving_dir + i + '/' + j + '/' + k + '/right/' + im):
                        all_right_img.append(driving_dir + i + '/' + j + '/' + k + '/right/' + im)

    return all_left_img, all_right_img, all_left_disp, test_left_img, test_right_img, test_left_disp


