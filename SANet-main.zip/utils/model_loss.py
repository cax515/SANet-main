from __future__ import absolute_import, division, print_function
from collections import namedtuple
import numpy as np
import torch as th
def gradient_x(img):
  gx = img[:,:,:-1] - img[:,:,1:]
  return gx

def gradient_y(img):
  gy = img[:,:-1,:] - img[:,1:,:]
  return gy

def gradientimg_x(img):
  gx = img[:,:,:,:-1] - img[:,:,:,1:]
  return gx

def gradientimg_y(img):
  gy = img[:,:,:-1,:] - img[:,:,1:,:]
  return gy

def get_disparity_smoothness_loss(disp, img):
  #print(disp.size())
  #print(img.size())
  disp_gradients_x = gradient_x(disp)
  disp_gradients_y = gradient_y(disp)

  image_gradients_x = gradientimg_x(img)
  image_gradients_y = gradientimg_y(img)

  weights_x = th.exp(-th.mean(th.abs(image_gradients_x))) 
  weights_y = th.exp(-th.mean(th.abs(image_gradients_y)))
  #print(weights_x)
  #print(th.mean(th.abs(disp_gradients_x)))
  smoothness_x = th.mean(th.abs(disp_gradients_x)) * weights_x 
  smoothness_y = th.mean(th.abs(disp_gradients_y)) * weights_y 
  return smoothness_x + smoothness_y

  